from lib.hand_eval import convert_string_to_int, score_best_five, eval_hand
from lib.board_correlation import straight_correlation, flush_correlation
from Global import State
from random import random


def try_to_check(legal_actions):
    check_action = [x for x in legal_actions if 'CHECK' in x]
    if not check_action:
        return 'FOLD'
    return check_action[0]

def quick_check_if_hole_helps(score, board):
    if len(board) == 3:
        board = board + [-1, -6]
    elif len(board) == 4:
        board = board + [-1]
    that_score = eval_hand(board)
    if that_score[0] == score[0]:
        return False
    return True

def split_raise(legal_actions):
    raising_action = [x for x in legal_actions if 'RAISE' in x or 'BET' in x]
    if not raising_action:
        return False, False
    r, lo, hi = raising_action[0].split(':')
    lo = int(lo)
    hi = int(hi)
    return lo, hi

def classify_pair_river(board, score):
    board = sorted([x / 4 for x in board])
    if score[1] > board[4]: return 10
    if score[1] == board[4]: return 9
    if score[1] > board[3] and score[1] < board[4]: return 8
    if score[1] == board[3]: return 7
    if score[1] > board[2] and score[1] < board[3]: return 6
    if score[1] == board[2]: return 5
    if score[1] > board[1] and score[1] < board[2]: return 4
    if score[1] == board[1]: return 3
    if score[1] > board[0] and score[1] < board[1]: return 2
    if score[1] == board[0]: return 1
    if score[1] < board[0]: return 0
    return 0

def board_correlation(board_cards):
    return max(flush_correlation(board_cards), \
            straight_correlation(board_cards))

DECK = 52
def i_has_the_nuts(hole, board_cards):
    my_score = score_best_five(hole + board_cards)
    counter = 0
    for card1 in range(DECK):
        if card1 in hole or card1 in board_cards: continue
        for card2 in range(card1 + 1, DECK):
            if card2 in hole or card1 in board_cards: continue
            counter += 1
            if my_score < score_best_five([card1, card2] + board_cards):
                return False
    return True

# TODO: Assign a probability to every possible hole cards that the
# opponent could have and whether each will win

NOT_PAIRED_BOARD = -1
def paired_board(board):
    board = sorted([x / 4 for x in board])
    if board[1] == board[0] or board[1] == board[2]:
        return board[1]
    if board[2] == board[3] or board[3] == board[4]:
        return board[3]
    return NOT_PAIRED_BOARD


VAL_OF_OUT = .02174 # 1 / 46
PAIR_ODDS = {0: .05, 1: .1, 2: .12, 3: .15, 4: .17, 5: .2, 6: .25, 7: .35, 8: .4, 9: .45, 10: .5}
HIGH_CARD = 0
PAIR = 1
TWO_PAIR = 2
THREE_OF_A_KIND = 3
STRAIGHT = 4
FLUSH = 5
FULL_HOUSE = 6

BLUFF_AT_SCARY_BOARD = .05
BLUFF_AT_REALLY_SCARY_BOARD = .15


class River(object):

    @classmethod
    def get_action(cls, data):
        # GETACTION potSize numBoardCards [boardCards] [stackSizes]
        # numActivePlayers [activePlayers] numLastActions [lastActions]
        # numLegalActions [legalActions] timebank
        data = data.split()
        getaction = data.pop(0)
        potSize = int(data.pop(0))
        numBoardCards = int(data.pop(0))

        board_cards = []
        for _ in range(numBoardCards):
            board_cards.append(convert_string_to_int(data.pop(0)))

        stack1 = int(data.pop(0))
        stack2 = int(data.pop(0))
        stack3 = int(data.pop(0))

        numActivePlayers = int(data.pop(0))
        active1 = data.pop(0)
        active2 = data.pop(0)
        active3 = data.pop(0)

        numLastActions = int(data.pop(0))

        prev_actions = []
        for _ in range(numLastActions):
            prev_actions.append(data.pop(0))
        State.hand_actions += prev_actions

        numLegalActions = int(data.pop(0))

        legal_actions = []
        for _ in range(numLegalActions):
            legal_actions.append(data.pop(0))

        if numLegalActions == 1:
            return legal_actions[0]

        State.timebank = float(data.pop(0))

        # These are the variables based on position
        score = score_best_five(board_cards + State.hole_cards)
        i_called = 'CALL' in prev_actions[0]
        i_got_the_nuts = i_has_the_nuts(State.hole_cards, board_cards)
        board_alone_score = score_best_five(board_cards)

        print 'River score', score

        if i_got_the_nuts:
            print 'I GOT THE NUTS'

        # CHECK / BET           1
        # CALL / FOLD / RAISE   2


        ############################ Case 1 ###################################
        #######################################################################
        # Nobody else has bet
        if any([x for x in legal_actions if 'CHECK' in x]):
            lo, hi = split_raise(legal_actions)
            if not lo: return try_to_check(legal_actions)

            # Max bet the nuts
            if i_got_the_nuts:
                lo, hi = split_raise(legal_actions)
                if not lo: return call_action
                return 'BET:%d' % hi

            # We bet if we have more than a pair
            if score[0] > PAIR and quick_check_if_hole_helps(score, board_cards):
                bet_prob = 1
            elif score[0] == PAIR and quick_check_if_hole_helps(score, board_cards):
                bet_prob = PAIR_ODDS[classify_pair_river(board_cards, score)]
            else:
                # This is our kicker to a pair on the board or just high card
                bet_prob = max(State.hole_cards) / 4 * .01

            if random() < bet_prob:
                if score[0] >= STRAIGHT:
                    return 'BET:%d' % hi

                # If they raised into us and we called, then do not attack
                if i_called: return try_to_check(legal_actions)

                if score[0] >= TWO_PAIR:
                    if paired_board(board_cards) == NOT_PAIRED_BOARD:
                        bet_amt = max(min(int(hi * State.aggressiveness), hi), lo)
                        return 'BET:%d' % bet_amt
                    else:
                        return 'BET:%d' % lo

                if score[0] >= PAIR and quick_check_if_hole_helps(score, board_cards) and \
                        classify_pair_river(board_cards, score) >= 5:
                    bet_amt = max(min(int(bet_prob * hi * State.aggressiveness), hi), lo)
                    return 'BET:%d' % bet_amt

                return 'BET:%d' % lo
            else:
                # Bluff at scary board
                if board_correlation(board_cards) >= 3 and not i_called:
                    if random() > BLUFF_AT_SCARY_BOARD:
                        bet_amt = max(min(int(2 * lo * State.aggressiveness), hi), lo)
                        print 'River bluff'
                        return 'BET:%d' % bet_amt

                if board_correlation(board_cards) >= 4 \
                        and not i_called:
                    if random() > BLUFF_AT_REALLY_SCARY_BOARD:
                        bet_amt = max(min(int(.1 * potSize * State.aggressiveness), hi), lo)
                        print 'River bluff'
                        return 'BET:%d' % bet_amt

                # Figure out if we are the last one to act and dont give free check
                if len(prev_actions) >= 2 and 'DEAL' in prev_actions[1] and 'CHECK' \
                        in prev_actions[0]:
                    bet_amt = max(min(int(.25 * potSize * State.aggressiveness), hi), lo)
                    return 'BET:%d' % bet_amt

                return try_to_check(legal_actions)


        ############################ Case 2 ###################################
        #######################################################################
        # Need to decide if we should FOLD / CALL / RAISE
        if any([x for x in legal_actions if 'CALL' in x]):
            # Never call a bet if we are playing the board
            if board_alone_score == score:
                return 'FOLD'

            # Compute pot odds
            call_action = [x for x in legal_actions if 'CALL' in x][0]
            call_amt = int(call_action.split(':')[-1])

            pot_odds = float(call_amt) / (call_amt + potSize)
            # Determine what the odds of winning are by guessing
            if score[0] <= TWO_PAIR:
                guessed_win_prob = 0
                # HIGH CARD
                if score[0] == HIGH_CARD:
                    guessed_win_prob = float(score[1][0] / 4) / 60
                elif score[0] == PAIR:
                    val = classify_pair_river(board_cards, score)
                    guessed_win_prob += PAIR_ODDS[val]
                    if not quick_check_if_hole_helps(score, board_cards):
                        guessed_win_prob *= .25
                elif score[0] == TWO_PAIR:
                    if board_alone_score[0] == TWO_PAIR:
                        if board_alone_score[1] < score[1] or board_alone_score[2] < score[2]:
                            guessed_win_prob = .5
                        else:
                            guessed_win_prob = .05 * max([x / 4 for x in State.hole_cards])
                    if paired_board(board_cards) != NOT_PAIRED_BOARD:
                        guessed_win_prob = .3
                        guessed_win_prob += .04 * (score[1] - paired_board(board_cards))
                    else:
                        guessed_win_prob += .6
                        guessed_win_prob += .04 * score[1]

                # Drop our odds if there is a scary board
                correlation = board_correlation(board_cards)
                if correlation >= 3:
                    guessed_win_prob *= .5
                if correlation >= 4:
                    guessed_win_prob *= .5

                if pot_odds < guessed_win_prob:
                    prev_bets = [x for x in prev_actions if 'RAISE' in x or 'BET' in x]
                    multibet = len(prev_bets) >= 2
                    if 2 * pot_odds < guessed_win_prob and not multibet:
                        lo, hi = split_raise(legal_actions)
                        if not lo: return call_action

                        if 4 * pot_odds < guessed_win_prob:
                            bet_amt = hi
                        else:
                            bet_amt = max(min(int(lo * State.aggressiveness), hi), lo)
                        return 'RAISE:%d' % bet_amt

                    if i_got_the_nuts:
                        lo, hi = split_raise(legal_actions)
                        if not lo: return call_action
                        return 'RAISE:%d' % hi

                    return call_action
                return 'FOLD'

            lo, hi = split_raise(legal_actions)
            if not lo: return call_action

            if score[0] >= STRAIGHT:
                if board_correlation(board_cards) >= 4 and not i_got_the_nuts:
                    return call_action
                return 'RAISE:%d' % hi

            if score[0] == THREE_OF_A_KIND and quick_check_if_hole_helps(score, board_cards):
                if board_alone_score[0] == score[0]:
                    return 'FOLD'
                correlation = board_correlation(board_cards)
                if correlation >= 4:
                    bet_amt = lo
                else:
                    bet_amt = max(min(int((1 + random()) / 2 * hi * \
                            State.aggressiveness), hi), lo)
                return 'RAISE:%d' % bet_amt

            if not quick_check_if_hole_helps(score, board_cards) and \
                    max([x / 4 for x in State.hole_cards]) != 12:
                return 'FOLD'

            if i_got_the_nuts:
                return 'RAISE:%d' % hi

            return call_action

        return 'CHECK'
